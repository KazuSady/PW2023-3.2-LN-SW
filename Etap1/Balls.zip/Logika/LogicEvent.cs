﻿namespace Logika
{
    public class LogicEvent
    {
        public ILogicBall ball;
        public LogicEvent(ILogicBall ball)
        {
            this.ball = ball;
        }
    }
}
