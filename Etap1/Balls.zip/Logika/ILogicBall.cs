﻿using Dane;
using System.ComponentModel;
using System.Drawing;

namespace Logika
{
    public abstract class ILogicBall
    {
        public static ILogicBall CreateLogicBall(int x, int y)
        {
            return new LogicBall(x, y);
        }

        public abstract Point Position { get; set; }
        public abstract void Update(Object o, DataEvent args);

        public abstract event EventHandler<LogicEvent> PropertyChanged;
    }
}
