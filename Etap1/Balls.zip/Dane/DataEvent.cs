﻿
namespace Dane
{
    public class DataEvent
    {
        public IBall ball;
        public DataEvent(IBall ball)
        {
            this.ball = ball;
        }
    }
}
